<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="/Unregistered_userCSS/mainCSS.css">
    <link rel="stylesheet" href="/Unregistered_user/CSS/meamnim.CSS">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        if (typeof jQuery == "undefined") {
            alert("not working");
        }
        </script>
    <title>המאמנים שלנו</title>
</head>
<body>
    <header id="header"></header>

    <main>
        <section id="sec1">
            <p class="h1">הכירו את המאמנים שלנו</p> <br>
            <img id="imgC" src="/Unregistered_user/images/meamnimPage.jpg">
        </section>
        <section class="sec1">
            <br> 
            <p class="p">
                אנו, צוות המאמנים של הסטודיו, מנוסים ומקצועיים מאוד. <br>
                אנו חדורי מטרה ומוטיבציה להוציא מכם המיטב! <br>
                 כולנו מיומנים בשיטות אימון שונות ומגוונות ומבטיחים להעניק לכם תכני כושר אשר יתאימו לכל אחד ואחד מכם בצורה המקצועית ביותר!
            </p>
            <p id="p2">נשמח להכיר גם אתכם!</p> <br>
        </section>

        <section class="sec3">
            <ul class="clearfix ul2">
                <li class="li2">
                <figure id="figure">
                    <img class="imgF" src="/Unregistered_user/images/edenA.jpeg" alt="edenAharony">
                    <figcaption id="figcaption">
                    <span style="font-weight: bold;">    היי, אני עדן! </span><br><br>
                    אני מאמנת כושר מוסמכת ובעלת תעודת הוראה ו-BA בחינוך גופני. <br>
                    עם הידע התיאורטי והנסיון שרכשתי, פיתחתי שיטת אימונים ייחודית המבוססת על האימון הפונקציונאליים אותה אני מיישם עד היום בסטודיו.
                    אני מאמינה בעבודה מקצועית ומדויקת. כזו שמתחדשת ומסונכרנת עם החידושים המדעיים בתחום הכושר וה-life-style.</p>
                    </figcaption>    
                </figure>
                </li>

                <li class="li2">
                    <figure id="figure">
                        <img class="imgF" src="/Unregistered_user/images/meamen2.jpg" alt="edenAharony">
                        <figcaption id="figcaption">
                            <span style="font-weight: bold;">היי, אני אמיתי!</span> <br><br>
                            מאז שאני זוכר את עצמי אני עוסק בספורט ובמיוחד קארטה. <br>
                            גם בצבא שירתתי כמאמן כושר בבסיס שדה דוב.<br>
                            ב-2017 סיימתי הכשרת מדריכי כושר בוינגייט ומאז אני מאמן ספורט.<br>
                            ב-2018 פתחתי חוגי נינג'ה ייחודיים לילדים בהם אני מקנה לילדים אהבה לספורט.<br>
                            מוטו לחיים: "לאמץ את הגוף זה אולי לא מה שאתם אוצים, אבל זה מה שאתם צריכים"
                        </figcaption>    
                    </figure>
                </li>

                <li class="li2">
                    <figure id="figure">
                        <img class="imgF" src="/Unregistered_user/images/meamen4.jpg" alt="edenAharony">
                        <figcaption id="figcaption">
                            <span style="font-weight: bold;"> היי, אני מאי!</span><br><br>
                            מאמנת פילאטיס ואימונים פונקציונאליים. תמיד אהבתי לעסוק בספורט וכבר בגיל 16 השתתפתי במרוצים למרחקים ארוכים. בצבא שירתתי כמדריכת כושר ולאחר מכן עשיתי קורס מאמני פילאטיס וספינינג.  ספורט תמיד היה בשבילי דרך חיים.  אני מאוד אוהבת להדריך קבוצות ואימונים אישיים ולראות בגאווה איך אנשים צולחים את האתגרים הפיזיים. את הפילאטיס אני מאוד אוהבת כי מנעד התרגילים והמקצבים בשיטה הוא רחב מאוד. הוא עובד יותר על שרירי הליבה והוא מצויין כספורט שיקומי לאחר פציעות ומקל על בעיות גב וברכיים. הוא אמנם איטי יותר מהפונקציונאלי אבל לא פחות קשה!    
                        </figcaption>    
                    </figure>
                </li>

                <li class="li2">
                    <figure id="figure">
                        <img class="imgF" src="/Unregistered_user/images/meamen3.jpg" alt="edenAharony">
                        <figcaption id="figcaption">
                            <span style="font-weight: bold;">היי, אני אורי הר-לב!</span> <br><br>
                            אני בוגר קורס מאמני חדר כושר מטעם וינגייט. מיד לאחר קבלת תעודת המאמן המשכתי להכשרות נוספות: כוכב 2-מאמנים אישיים מטעם הולמס פלייס, מדריך אימון TRX, מדריך אימון פונקציונלי, טריגר פוינט-טיפול בכאב. אני מאמן בשילוב בין כל עקרונות האימון ובהתאמה לכל דרגות הקושי של המתאמנים ולפי הצרכים של כל אחד, כולל שיקום מפציעות. בנוסף, אני סטודנט במסלול לתזונת ספורט בוינגייט. נכנסתי כשותף מנהל לסטודיו החדש שפתחנו בקיבוץ שפיים.
                        </figcaption>    
                    </figure>
                </li>
            </ul>
        </section>

        
        <div style="clear: both;"></div>
    </main>

    <footer id="footer"></footer>
    <script>
        $(document).ready(
            function(){
              $("#header").load("navbar/navbar.html");
              $("#footer").load("footer.html");
            }            
         )

    </script>
</body>
</html>