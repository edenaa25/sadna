<!DOCTYPE html>
<html dir="rtl" lang="he" xml:lang="he">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="/Unregistered_user/CSS/mainCSS.css">
    <link rel="stylesheet" href="/Unregistered_user/CSS/training.CSS">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        if (typeof jQuery == "undefined") {
            alert("not working");
        }
        </script>
    <title>דף אימונים</title>
</head>
<body>
    <header id="header"></header>
    <div style="clear: both;"></div>
    <main>
        <section class="sec1">
           <h1>
               אימונים מוקלטים ומותאמים אישית עבורך
               <hr class="new4">
           </h1><br> <br>
           <p id="p1">
               בואו להכיר את סוגי האימונים השונים אשר הסטודיו שלנו מציע במיוחד בשבילכם מטעם מאמני הכושר המקצועיים שלנו!
           </p>
        </section>
        <section class="sec2">
            <div id="div2" class="clearfix">
                <img id="imgSec2" src="/Unregistered_user/images/trainingSec2.png">
                <div class="txtSec2">    
                    <h1 class="h1sec2">ממשיכים לשמור על כושר ועל שפיות</h1>
                    <p style="font-size: large;">
                        <span style="font-weight: bold;">היי! נעים מאוד, ברוכים הבאים לסטודיו שלנו</span><br>
                        אצלנו האימונים מועברים בצורה היברדית, כלומר כל לקוח שלנו מקבל סרטוני אימוני כושר שבועיים אותם הוא צריך לבצע במהלך השבוע לאורך כל תהליך ההרזייה שלו.<br><br>
                        לפניי מספר חודשים הקורונה נכנסה לחיינו בסערה וגרמה לעסקים לחשב מסלול מחדש וגם אורך חיינו השתנה בעקבות כך עם הרבה עבודה מהבית. <br>
                        <br>
                        מערכת האימונים שלנו מאפשרת לך להתאמן בכל מקום ומכל זמן שתרצה!<br>
                        מוזמים לקרוא ולהכיר את סוגי האימונים שלנו
                    </p>
                </div>
            </div>
        </section>
        <div style="clear: both;"></div>
        
        <section class="sec3">
            <ul class="clearfix ul2">
                <li class="li2">
                <figure id="figure">
                    <img class="imgF" src="/Unregistered_user/images/funcTraining.png" alt="functional training">
                    <figcaption id="figcaption">
                    <span style="font-weight: bold;">    אימונים פונקציונאלים </span><br><br>
                    אימון פונקציונלי הוא סוג של פעילות גופנית, המאופיינת במינימום מכשור ובזמן ביצוע קצר.<br>
                    בגוף האדם ישנם שרירי ליבה, המייצבים את עמוד השדרה והם מורכבים משרירי בטן עמוקים (רחב בטני, אלכסונים פנימיים וחיצוניים ושרירים ישרים). האימון הפונקציונלי מערב שרירים אלו עם קבוצות שרירים שונות, הפועלות יחד בכמה מישורי תנועה במקביל לצורך במתן יציבות וכוח.<br>
                    לכן אימון זה שונה מעבודת חדר כושר, המבודדת שריר אחד בלבד או מתמקדת בו תוך נטרול עבודת שרירי הליבה מעבודת השרירים הכללית.
                    </figcaption>    
                </figure>
                </li>

                <li class="li2">
                    <figure id="figure">
                        <img class="imgF" src="/Unregistered_user/images/aerobicTraining.png" alt="edenAharony">
                        <figcaption id="figcaption">
                            <span style="font-weight: bold;"> אימוני ארובי</span><br><br>
                            פעילות אירובית היא פעילות הכוללת מאמץ גופני תת-מרבי המפעיל קבוצות שרירים גדולות לזמן ממושך. לעוסקים בספורט ולחובבנים קיים מגוון רחב של פעילויות אירוביות כגון: הליכה, ריצה, רכיבה על אופניים, שחייה, סקי, זומבה ועוד.

                            הפעילות האירובית מעלה את צריכת החמצן בגוף ומגבירה את קצב הלב שמספק את החמצן הדרוש לשרירים. בשונה מפעילות אנאירובית, הפעילות האירובית נעשית תוך שימוש בחמצן. <br>
                            אימון אירובי מעודד את הגוף לנצל את מאגרי השומן מכיוון שבזמן ביצועו מופעלות קבוצות שרירים גדולות במשך זמן. אימון אירובי גם מגביר את קצב הנשימה, את קצב הלב ואת זרימת הדם לשרירים, ואם מבצעים אימון אירובי בעקביות משיגים שיפור בסבולת לב-ריאה, עלייה במסת שריר וירידה באחוזי השומן.
                        </figcaption>    
                    </figure>
                </li>

                <li class="li2">
                    <figure id="figure">
                        <img class="imgF" src="/Unregistered_user/images/powerTraining.png" alt="edenAharony">
                        <figcaption id="figcaption">
                            <span style="font-weight: bold;"> אימוני כוח</span><br><br>
                            אימון כוח הוא בדיוק מה שהגוף זקוק לו כדי להילחם באובדן שריר, מסת עצם וכוח שמגיעים עם הגיל. כולם, ללא קשר לגיל, צעירים או מבוגרים, צריכים לבצע אימוני כוח מגוונים כחלק מלו"ז האימונים השבועי.<br>
                            לא משנה אם אתם מבקשים ומבקשות להוריד במשקל ולהתחטב, לעצב את הגוף או בכלל לשפר את הבריאות ולהרגיש טוב יותר, הדרך הטובה ביותר היא פעילות גופנית. אבל החוכמה הגדולה טמונה בשילוב אימונים נכון, שיעצים וימקסם את האפקט – גם להעלות את מסת השריר וגם להוריד את אחוזי השומן.

הדרך הטובה ביותר להשיג את שתי המטרות היא שילוב אימונים שיש להם השפעה פיזיולוגית שונה: אימון כוח המחזק את השרירים עם אימון אירובי. 

אימוני כוח (משקולות, TRX, מכשירי התנגדות שונים) מפעילים קבוצות שרירים מסוימות בקצב יציב למשך פרק זמן מסוים. אימוני כוח מסייעים להגדיל את כוחם של השרירים ומעלים את מסת השריר. כשמבצעים אימוני כוח לאורך זמן ובאופן רציף נוצר שינוי באופן חילוף החומרים, וגם בזמן מנוחה יש עלייה בניצול הסוכרים ובשריפת השומנים.
                            האימון יכול להתבצע בסטודיו או בבית, תוך שימוש במעט מאוד ציוד.
                        </figcaption>    
                    </figure>
                </li>
            </ul>
        </section>
    </main>


    

    <footer id="footer"></footer>
    <script>
        $(document).ready(
            function(){
              $("#header").load("navbar/navbar.html");
              $("#footer").load("footer.html");
            }            
         )

    </script>
</body>
</html>